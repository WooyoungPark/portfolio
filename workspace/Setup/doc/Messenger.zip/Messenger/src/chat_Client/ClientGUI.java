package chat_Client;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import chat_Server.ServerGUI;

public class ClientGUI extends JFrame implements ActionListener{

	private JTextArea jta = new JTextArea(40,25);
	private JTextField jtf =  new JTextField(25);
	private static ClientBackground client  = new ClientBackground();
	private static  String nickName;
	
	public ClientGUI() {
		
		// ������ ���� �� ��Ʈ�� ����
		add(jta, BorderLayout.CENTER);
		add(jtf, BorderLayout.SOUTH);
		jtf.addActionListener(this);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setBounds(200, 100, 400, 600);
		setTitle("Client");
		
		//��׶��� ����
		client.setGui(this);
		client.connet();
		
	}
	
	@Override
	//�� ġ�� ������ �κ�
	public void actionPerformed(ActionEvent arg0) {
		String msg =  jtf.getText() +"\n";
		client.sendMsg(nickName + " : " + msg);
		jtf.setText("");
	}
	
	public void appendMsg(String msg){
		jta.append(msg + "\n");
		
	}
	
	public static void main(String[] args) {
		System.out.println("����� �г����� �������� : ");
		nickName = new Scanner(System.in).nextLine();
		
		client.setNickname(nickName);
		
		new ClientGUI();
	}
	

}
