package chat_Client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

public class ClientBackground {
	private Socket socket;
	
	private DataInputStream in;
	private DataOutputStream out;
	private ClientGUI gui;
	private String msg;

	private String nickName;
	
	
	public void setGui(ClientGUI gui) {
		this.gui = gui;
	}

	public ClientBackground() {
		
	}
	
	public void connet() {
		try {
			
			socket = new Socket("localhost", 7777);
			System.out.println("���� ���� ��");
			
			//����� �� �ִ� ��� ����
			out = new DataOutputStream(socket.getOutputStream());
			in = new DataInputStream(socket.getInputStream());
			
			out.writeUTF(nickName);	//�������ڸ��� �г��� ����
			// �����κ��� ������ �޽��� ǥ��
			while(in !=null) {
				msg = in.readUTF();
				gui.appendMsg(msg);
			}
			
			
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	public void sendMsg(String msg) {
		try {
			out.writeUTF(msg);
			//System.out.println("Client to Server / �޽��� ���� �Ϸ�");
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}
	

	public static void main(String[] args) {
		ClientBackground C = new ClientBackground();
		System.out.println("<Client>");
		C.connet();

	}

	public void setNickname(String nickName) {
		this.nickName = nickName;		
	}

}
