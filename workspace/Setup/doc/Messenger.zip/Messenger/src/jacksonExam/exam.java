package jacksonExam;
import java.io.FileWriter;
import java.io.IOException;

import org.json.simple.*;



public class exam {

	public exam() {
		
	}
	
	public static void main(String[] args) {
		//Json ��ü ����.
        JSONObject jobj = new JSONObject();
        jobj.put("name", "JDH");
        jobj.put("company", "acanet");
        jobj.put("age", "26");
        System.out.println(jobj.get("name").toString());
        
        JSONObject jobj2 = new JSONObject();
       
        //Json Array ����.
        JSONArray maglist = new JSONArray();
        
        jobj2.put("name", "JDH");
        jobj2.put("company", "acanet");
        jobj2.put("age", "26");
        maglist.add(jobj2);
        maglist.add("hello JSON");

        jobj.put("list", maglist);

        try {

               FileWriter file = new FileWriter("e:\\myJson.json");
               file.write(jobj.toJSONString());
               file.flush();
               file.close();
        } catch(IOException e) {
               e.printStackTrace();
        }
        System.out.println("Create JSON Object : "+jobj);
		
		
	}

}
